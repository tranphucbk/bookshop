<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="UTF-8">
		<title>Send mail</title>

	</head>
	<body>
		<form  class="" action="send.php" method="POST">
			Email <input type="email" name="email" value=""><br>
			Subject<input type="text" name="subject" value=""><br>
			Message<input type="text" name="message" value=""><br>
			<button type="submit" name="send">send</button>
		</form>
	</body>
</html>