<div class="sidebar">
				<ul class="list_sidebar">
					<li><a href="#">N5</a></li>
					<li><a href="#">N4</a></li>
					<li><a href="#">N3</a></li>
					<li><a href="#">N2</a></li>
					<li><a href="#">N1</a></li>
				</ul>
			</div>