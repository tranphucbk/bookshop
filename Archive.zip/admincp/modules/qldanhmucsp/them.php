<p> Them danh muc san pham </p>

<table border="1" width="50%" >
	<form method="POST" action="modules/qldanhmucsp/xuly.php">
		<tr>
			<td>Ten danh muc</td>
			<td><input type="text" name="tendanhmuc"></td>
		</tr>
		<tr>
			<td>Thu tu</td>
			<td><input type="text" name="thutu"></td>
		</tr>

		<tr>
			<td colspan="2"><input type="submit" name="themdanhmuc" value="Them danh muc san pham"></td>
		</tr>
	</form>
</table>