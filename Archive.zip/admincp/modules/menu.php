<ul class="admincp_list">
	<li><a href="index.php?action=qldanhmucsp&query=them"> Quan ly danh muc san pham</a></li>
	<li><a href="index.php?action=qlsp&query=them"> Quan ly san pham</a></li>
	<li><a href="index.php?action=qldonhang&query=lietke"> Quan ly don hang</a></li>
	
</ul>
